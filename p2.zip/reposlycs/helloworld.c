/*
 * Autor: Angel Martin Moreno
 * Fecha: 25-05-2021
 *
 * /

#include "include/myinclude.h"

int main
{
	f();
	
	return 0;
}
